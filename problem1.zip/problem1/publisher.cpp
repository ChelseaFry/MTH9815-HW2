#include <boost/interprocess/shared_memory_object.hpp>
#include <boost/interprocess/mapped_region.hpp>
#include <iostream>

int main() {
    using namespace boost::interprocess;

    try {
        // Create a shared memory object
        shared_memory_object shm(create_only, "SharedMemory", read_write);

        // Set the size of the shared memory
        shm.truncate(sizeof(int));

        // Map the shared memory into the process's address space
        mapped_region region(shm, read_write);

        // Write an integer to shared memory
        int *data = static_cast<int*>(region.get_address());
        *data = 42; // Example integer

        std::cout << "Publisher: Wrote " << *data << " to shared memory." << std::endl;
    } catch (interprocess_exception &ex) {
        std::cerr << "Error: " << ex.what() << std::endl;
    }

    return 0;
}
