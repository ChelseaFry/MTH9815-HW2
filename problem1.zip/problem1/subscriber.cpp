#include <boost/interprocess/shared_memory_object.hpp>
#include <boost/interprocess/mapped_region.hpp>
#include <iostream>

int main() {
    using namespace boost::interprocess;

    try {
        // Open the shared memory object
        shared_memory_object shm(open_only, "SharedMemory", read_only);

        // Map the shared memory into the process's address space
        mapped_region region(shm, read_only);

        // Read the integer from shared memory
        int *data = static_cast<int*>(region.get_address());
        std::cout << "Subscriber: Read " << *data << " from shared memory." << std::endl;
    } catch (interprocess_exception &ex) {
        std::cerr << "Error: " << ex.what() << std::endl;
    }

    return 0;
}
