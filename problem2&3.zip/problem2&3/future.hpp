#ifndef FUTURE_HPP
#define FUTURE_HPP

#include <iostream>
#include "products.hpp"
#include "boost/date_time/gregorian/gregorian.hpp"

using namespace std;
using namespace boost::gregorian;

/**
 * Modeling of a Future Product
 */
class Future : public Product
{
public:
    // Constructor with arguments
    Future(string _productId, date _expiryDate, double _contractSize);

    // Default constructor
    Future() : Product("", FUTURE), expiryDate(date()), contractSize(0.0) {}

    // Get the expiry date of the Future
    date GetExpiryDate() const;

    // Get the contract size of the Future
    double GetContractSize() const;

    // Overload the << operator to print the Future
    friend ostream& operator<<(ostream &output, const Future &future);

private:
    date expiryDate;      // Expiry date of the Future
    double contractSize;  // Contract size of the Future
};

/**
 * EuroDollarFuture: Subclass of Future
 */
class EuroDollarFuture : public Future
{
public:
    // Constructor with arguments
    EuroDollarFuture(string _productId, date _expiryDate, double _contractSize, double _interestRate);

    // Default constructor
    EuroDollarFuture() : Future("", date(), 0.0), interestRate(0.0) {}

    // Get the interest rate
    double GetInterestRate() const;

private:
    double interestRate; // Interest rate associated with the EuroDollarFuture
};

/**
 * BondFuture: Subclass of Future
 */
class BondFuture : public Future
{
public:
    // Constructor with arguments
    BondFuture(string _productId, date _expiryDate, double _contractSize, string _underlyingBond);

    // Default constructor
    BondFuture() : Future("", date(), 0.0), underlyingBond("") {}

    // Get the underlying bond
    string GetUnderlyingBond() const;

private:
    string underlyingBond; // Underlying bond of the BondFuture
};

/**
 * Implementation of Future class
 */
Future::Future(string _productId, date _expiryDate, double _contractSize) 
    : Product(_productId, FUTURE), expiryDate(_expiryDate), contractSize(_contractSize) {}

date Future::GetExpiryDate() const
{
    return expiryDate;
}

double Future::GetContractSize() const
{
    return contractSize;
}

ostream& operator<<(ostream &output, const Future &future)
{
    output << "Expiry: " << future.GetExpiryDate() << ", Contract Size: " << future.GetContractSize();
    return output;
}

/**
 * Implementation of EuroDollarFuture class
 */
EuroDollarFuture::EuroDollarFuture(string _productId, date _expiryDate, double _contractSize, double _interestRate)
    : Future(_productId, _expiryDate, _contractSize), interestRate(_interestRate) {}

double EuroDollarFuture::GetInterestRate() const
{
    return interestRate;
}

/**
 * Implementation of BondFuture class
 */
BondFuture::BondFuture(string _productId, date _expiryDate, double _contractSize, string _underlyingBond)
    : Future(_productId, _expiryDate, _contractSize), underlyingBond(_underlyingBond) {}

string BondFuture::GetUnderlyingBond() const
{
    return underlyingBond;
}

#endif
