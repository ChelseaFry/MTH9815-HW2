#ifndef FUTURE_PRODUCT_SERVICE_HPP
#define FUTURE_PRODUCT_SERVICE_HPP

#include <map>
#include "soa.hpp"
#include "future.hpp"

/**
 * Future Product Service to own reference data over a set of futures.
 * Key is the productId string, value is a Future.
 */
class FutureProductService : public Service<string, Future>
{
public:
    // Constructor
    FutureProductService();

    // Return the Future data for a particular product identifier
    Future& GetData(string productId);

    // Add a Future to the service (convenience method)
    void Add(Future &future);

private:
    map<string, Future> futureMap; // Cache of Future products
};

FutureProductService::FutureProductService()
{
    futureMap = map<string, Future>();
}

Future& FutureProductService::GetData(string productId)
{
    return futureMap[productId];
}

void FutureProductService::Add(Future &future)
{
    futureMap.insert(pair<string, Future>(future.GetProductId(), future));
}

#endif
