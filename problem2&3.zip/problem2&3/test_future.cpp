#include <iostream>
#include "future.hpp"
#include "future_product_service.hpp"

using namespace std;
using namespace boost::gregorian;

int main()
{
    // Create a EuroDollar Future
    date expiryDate1(2024, Dec, 15);
    EuroDollarFuture euroFuture("EuroFuture1", expiryDate1, 1000000, 2.5);

    // Create a Bond Future
    date expiryDate2(2025, Jun, 30);
    BondFuture bondFuture("BondFuture1", expiryDate2, 2000000, "912828M56");

    // Create a FutureProductService
    FutureProductService futureService;

    // Add the EuroDollar Future to the service and retrieve it
    futureService.Add(euroFuture);
    Future &retrievedEuroFuture = futureService.GetData("EuroFuture1");
    cout << "EuroDollar Future: " << retrievedEuroFuture << endl;

    // Add the Bond Future to the service and retrieve it
    futureService.Add(bondFuture);
    Future &retrievedBondFuture = futureService.GetData("BondFuture1");
    cout << "Bond Future: " << retrievedBondFuture << endl;

    return 0;
}
